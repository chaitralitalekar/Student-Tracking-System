package com.example.dhruv.myminiproject;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class documentList extends AppCompatActivity {
    //ListView docslist;
    // Write a message to the database
    FirebaseDatabase database;
    DatabaseReference myRef ;
    private ListView listDoc;
    private ArrayAdapter<String> new_adapter;
    private ArrayList<String> arraynewList;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_document_list);
       // listDoc = findViewById(R.id.docslistview);
        final String studname = getIntent().getStringExtra("studname");
        /*
        sumit ikde list madhe tya username che sagle documents read karun adapter ni display kar.
         radfromdb madhe student name la check kar with studname.equals()
        */
         database = FirebaseDatabase.getInstance();
         myRef = database.getReference("Documents");
         //listDoc = (ListView) findViewById(R.id.docslistview);
            //docNameArray=new ArrayList<>();
         arraynewList = new ArrayList<String>();
         myRef.addValueEventListener(new ValueEventListener() {
             @Override
             public void onDataChange(DataSnapshot dataSnapshot) {

                 for(DataSnapshot i:dataSnapshot.getChildren())
                 {
                     dbEntry doc=i.getValue(dbEntry.class);

                     arraynewList.add(new String(doc.getDocName()));
                     Toast.makeText(documentList.this,doc.getDocName(),Toast.LENGTH_SHORT).show();
                 }
             }

             @Override
             public void onCancelled(DatabaseError databaseError) {

             }
         });
        //String[] arr = new String[arraynewList.size()];  //convert arrylist to string array
        //arr =arraynewList.toArray(arr);
        String[] arr=new String[]{"ffa","db","cdds","dsdd","fde","ffdd"};
        //new_adapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_checked, arraynewList);
       // new_adapter = new ArrayAdapter<String>(getApplicationContext(),R.layout.listtextview, arr);
        listDoc.setChoiceMode(listDoc.CHOICE_MODE_MULTIPLE);

        // Here, you set the data in your ListView
        listDoc.setAdapter(new_adapter);
    }
}
