package com.example.dhruv.myminiproject;

import android.content.Intent;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.util.ArrayList;
import java.util.UUID;

//import droidninja.filepicker.FilePickerBuilder;
//document
public class demoActivity extends AppCompatActivity {
    FirebaseStorage storage;
    StorageReference storageReference;
    FirebaseDatabase database;
    DatabaseReference myref;
    String docUrl;
    Button subBtn;
    public static Uri selectedDocument;
    EditText documentName;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_demo);
        final ArrayList<String> filePaths=new ArrayList<>();
        filePaths.add("/Internal storage/Download");
        database = FirebaseDatabase.getInstance();
        storage = FirebaseStorage.getInstance();
        storageReference = storage.getReference();
        Button b1=(Button)findViewById(R.id.button8);
        subBtn = findViewById(R.id.button10);
        documentName=findViewById(R.id.documentName);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Intent i=new Intent(demoActivity.this,Main2Activity.class);
                //FilePickerBuilder.getInstance().setMaxCount(5).setSelectedFiles(filePaths).setActivityTheme(R.style.AppTheme).pickPhoto(demoActivity.this);
                Intent intent=new Intent();
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(intent,"Select Picture"),1);
                Uri selectedImageUri = intent.getData();
                if (null !=selectedImageUri){
                    String[] filePathColumn = { MediaStore.Images.Media.DATA };
                    Toast.makeText(demoActivity.this, filePathColumn+selectedImageUri.toString(),
                            Toast.LENGTH_LONG).show();
                }
                }



        });
        subBtn.setEnabled(false);

        Button b2=(Button)findViewById(R.id.button9);
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Intent i=new Intent(MainActivity.this,Main2Activity.class);
                //FilePickerBuilder.getInstance().setMaxCount(5).setSelectedFiles(filePaths).setActivityTheme(R.style.AppTheme).pickDocument(demoActivity.this);
                Intent intent = new Intent();
                intent.setType("*/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(intent, "Select File"), 2);
                Uri selectedDocumentUri = intent.getData();
                if (null != selectedDocumentUri) {
                    String[] filePathColumn = {MediaStore.Images.Media.DATA};
                    Toast.makeText(demoActivity.this, filePathColumn + selectedDocumentUri.toString(),
                            Toast.LENGTH_LONG).show();
                }


            }
        });
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {

        super.onActivityResult(requestCode, resultCode, data);

        try {

            // When an Image is picked

            if (requestCode == 1 && resultCode == RESULT_OK

                    && null != data) {

                // Get the Image from data



                Uri selectedImage = data.getData();

                String[] filePathColumn = { MediaStore.Images.Media.DATA };
                Toast.makeText(demoActivity.this, filePathColumn+"-"+selectedImage.toString()+"",Toast.LENGTH_LONG).show();


                /*// / Get the cursor
                /
                Cursor cursor = getContentResolver().query(selectedImage,

                        filePathColumn, null, null, null);

                // Move to first row

                cursor.moveToFirst();



                int columnIndex = cursor.getColumnIndex(filePathColumn[0]);

                imgDecodableString = cursor.getString(columnIndex);

                cursor.close();

                ImageView imgView = (ImageView) findViewById(R.id.imgView);

                // Set the Image in ImageView after decoding the String

                imgView.setImageBitmap(BitmapFactory

                        .decodeFile(imgDecodableString));*/



            }
            else if(requestCode == 2 && resultCode == RESULT_OK

                    && null != data) {

                // Get the Document from data


                selectedDocument = data.getData();
                subBtn.setEnabled(true);
                //String[] filePathColumn = {MediaStore.Files.Media.DATA};
                Toast.makeText(demoActivity.this, selectedDocument.toString() + "", Toast.LENGTH_LONG).show();

                subBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        StorageReference ref = storageReference.child("docs/" + UUID.randomUUID().toString());
                        ref.putFile(selectedDocument).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                docUrl = taskSnapshot.getDownloadUrl().toString();
                                writeDb(Main2Activity.getName(),docUrl);
                            }
                        });
                    }
                });
            }
            else {

                Toast.makeText(this, "You haven't picked Image or Document",

                        Toast.LENGTH_LONG).show();

            }

        } catch (Exception e) {

            Toast.makeText(this, "Something went wrong", Toast.LENGTH_LONG)

                    .show();

        }



    }
public void writeDb(String name,String downurl)
{
 myref= database.getReference().child("Documents");
 dbEntry newEntry = new dbEntry(name,downurl,documentName.getText().toString().trim());
 myref.push().setValue(newEntry).addOnSuccessListener(new OnSuccessListener<Void>() {
     @Override
     public void onSuccess(Void aVoid) {
         Toast.makeText(demoActivity.this,"Sucessfully written to db", Toast.LENGTH_SHORT).show();
         finish();
     }
 });

}
}
