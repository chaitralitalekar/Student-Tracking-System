package com.example.dhruv.myminiproject;

import android.app.DatePickerDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Calendar;

public class doxRetrieve extends AppCompatActivity {


    FirebaseDatabase database;
    DatabaseReference myRef ;
    private ListView list;
   // private ArrayAdapter<String> adapter;
    private ArrayList<String> arrayList;
    private ArrayList<dbEntry> arrayList1;






    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dox_retrieve);
       // String studname = getIntent().getStringExtra("studname");
        //addElements();
        //populateListView();

        database = FirebaseDatabase.getInstance();
        myRef = database.getReference("Documents");
        list = (ListView) findViewById(R.id.dynamic1);
        //list = (ListView) findViewById(R.id._dynamic);
        arrayList = new ArrayList<String>();
        arrayList1 = new ArrayList<dbEntry>();

        //adding elements into collection
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                for(DataSnapshot i:dataSnapshot.getChildren())
                {
                    dbEntry doc=i.getValue(dbEntry.class);
                    arrayList1.add(doc);
                    arrayList.add(new String(doc.getDocName()));
                    Toast.makeText(doxRetrieve.this,doc.getDocName(),Toast.LENGTH_SHORT).show();
                }
                ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(
                        getApplicationContext(),
                        android.R.layout.simple_list_item_1,
                        arrayList );

                list.setAdapter(arrayAdapter);
                list.setOnItemClickListener(new AdapterView.OnItemClickListener() {

                    public void onItemClick(AdapterView <?> parentAdapter, View view, int position,
                                            long id) {


                        dbEntry obj=(dbEntry) arrayList1.get(position);
                        Toast.makeText(doxRetrieve.this, obj.getUrlField()+"", Toast.LENGTH_SHORT).show();

                        String url = obj.getUrlField();
                        Intent intent = new Intent(Intent.ACTION_VIEW);
                        intent.setDataAndType(Uri.parse(url), "application/pdf");
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        Intent newIntent = Intent.createChooser(intent, "Open File");
                        try {
                            startActivity(newIntent);
                        } catch (ActivityNotFoundException e) {
                            // Instruct the user to install a PDF reader here, or something
                        }
                    }
                });
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });



        // Adapter: You need three parameters 'the context, id of the layout (it will be where the data is shown),
        // and the array that contains the data




    }

}
