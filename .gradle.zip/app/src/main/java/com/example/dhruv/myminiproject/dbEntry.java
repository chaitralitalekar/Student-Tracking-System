package com.example.dhruv.myminiproject;

import java.io.Serializable;

public class dbEntry implements Serializable {
    private String nameField;
    private String urlField;
    private String docName;

    public dbEntry() {
    }

    public dbEntry(String nameField, String urlField,String docName) {
        this.nameField = nameField;
        this.urlField = urlField;
        this.docName=docName;
    }

    public String getNameField() {
        return nameField;
    }

    public void setNameField(String nameField) {
        this.nameField = nameField;
    }

    public String getUrlField() {
        return urlField;
    }

    public void setUrlField(String urlField) {
        this.urlField = urlField;
    }

    public String getDocName() {
        return docName;
    }

    public void setDocName(String docName) {
        this.docName = docName;
    }
}
