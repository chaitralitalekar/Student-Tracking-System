package com.example.dhruv.myminiproject;


import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
//Signup
public class Main13Activity extends AppCompatActivity {

    private FirebaseAuth mAuth;
    private EditText email;
    private EditText pass;
    private EditText apass;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main13);
        email = (EditText) findViewById(R.id.mail1);
        pass = (EditText) findViewById(R.id.Epass1);
        apass = (EditText) findViewById(R.id.Cpass1);
        mAuth = FirebaseAuth.getInstance();



            Button b12=(Button)findViewById(R.id.button12);
            b12.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String cpass= apass.getText().toString();
                    String password = pass.getText().toString();
                    String em = email.getText().toString();
                    Toast.makeText(Main13Activity.this, em+password,
                            Toast.LENGTH_LONG).show();
                    if (cpass.equals(password)){
                        mAuth.createUserWithEmailAndPassword(em, password)
                                .addOnCompleteListener(Main13Activity.this, new OnCompleteListener<AuthResult>() {
                                    @Override
                                    public void onComplete(@NonNull Task<AuthResult> task) {
                                        if (task.isSuccessful()) {
                                            // Sign in success, update UI with the signed-in user's information
                                            FirebaseUser user = mAuth.getCurrentUser();
                                           // Toast.makeText(Main13Activity.this, "User registered",
                                                   // Toast.LENGTH_LONG).show();

                                            Intent i = new Intent(Main13Activity.this, MainActivity.class);
                                            startActivity(  i);

                                        } else {
                                            Toast.makeText(Main13Activity.this, "User already exists",
                                                    Toast.LENGTH_LONG).show();


                                        }

                                        // ...
                                    }
                                });
                }
                    else{
                        Toast.makeText(Main13Activity.this, "Password entered and the its confirmation do not match",
                                Toast.LENGTH_LONG).show();





                    }

                }

            });


    }
}
