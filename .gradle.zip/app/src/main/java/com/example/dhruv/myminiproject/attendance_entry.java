package com.example.dhruv.myminiproject;

import android.util.SparseBooleanArray;

import java.io.Serializable;

public class attendance_entry implements Serializable {
    String attendancelist;
    String attendanceDate;
    public attendance_entry() {
    }

    public attendance_entry(String attendancelist, String attendanceDate) {
        this.attendancelist = attendancelist;
        this.attendanceDate = attendanceDate;
    }

    public String getAttendancelist() {
        return attendancelist;
    }

    public void setAttendancelist(String attendancelist) {
        this.attendancelist = attendancelist;
    }

    public String getAttendanceDate() {
        return attendanceDate;
    }

    public void setAttendanceDate(String attendanceDate) {
        this.attendanceDate = attendanceDate;
    }
}
