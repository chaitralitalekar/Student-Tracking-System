package com.example.dhruv.myminiproject;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class testing extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_testing);
    }
}
