package com.example.dhruv.myminiproject;

import android.content.Intent;
import android.support.design.widget.TextInputEditText;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

//import droidninja.filepicker.FilePickerBuilder;

//Teacher activity page
public class Main5Activity extends AppCompatActivity {
    private TextView TV;
    private Spinner SP;
    Button assgnCheck;
    TextInputEditText studName;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main5);
        TV= (TextView) findViewById(R.id.textView6);
        SP= (Spinner) findViewById(R.id.spinner2);
        assgnCheck = findViewById(R.id.asscheck);
        studName = findViewById(R.id.studname);
        Button b3=(Button)findViewById(R.id.button4);
        assgnCheck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Intent i = new Intent(Main5Activity.this,documentList.class);
                Intent i= new Intent(Main5Activity.this,doxRetrieve.class);
                i.putExtra("studname",studName.getText().toString());
                startActivity(i);
            }
        });
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name=SP.getSelectedItem().toString();
                switch (name) {
                    case "DBMS":

                        Intent i = new Intent(Main5Activity.this, Main6Activity.class);
                        startActivity(i);
                        break;
                    case "CN":
                        Intent i1 = new Intent(Main5Activity.this, Main7Activity.class);
                        startActivity(i1);
                        break;
                    case "ISEE":
                        Intent i2 = new Intent(Main5Activity.this, Main8Activity.class);
                        startActivity(i2);
                        break;

                }
            }

        });
    }

}
