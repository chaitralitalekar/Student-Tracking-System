package com.example.dhruv.myminiproject;
//CN ATTENDaNCE PAGE FOR TEACHER
import android.app.DatePickerDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.SparseBooleanArray;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.Calendar;

public class Main7Activity extends AppCompatActivity {

    private int mYear;
    private int mMonth;
    private int mDay;
    private TextView tv;
    private ListView list;
    private ArrayAdapter<String> adapter;
    private ArrayList<String> arrayList;
    FirebaseDatabase database;
    DatabaseReference myref;
    SparseBooleanArray todaysattendance;
    Button addbtn;
    String att;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main6);
        //addElements();
        //populateListView();
        final Calendar c = Calendar.getInstance();
        mYear = c.get(Calendar.YEAR);
        mMonth = c.get(Calendar.MONTH);
        mDay = c.get(Calendar.DAY_OF_MONTH);
        tv = (TextView) findViewById(R.id.tv);
        database = FirebaseDatabase.getInstance();

        DatePickerDialog datePickerDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                tv.setText(dayOfMonth + "-" + month + "-" + year);
            }
        },mYear,mMonth,mDay);
        datePickerDialog.show();

        list = (ListView) findViewById(R.id.dynamic);
        arrayList = new ArrayList<String>();

        //adding elements into collection
        for(int i=1;i<81;i++) {
            //int number = -782;
            String numberAsString = Integer.toString(i);
            arrayList.add(new String(numberAsString));
            //arrayList.add(new String("20"));
            //arrayList.add(new String("30"));
            //arrayList.add(new String("40"));
            //arrayList.add(new String("50"));
        }

        // Adapter: You need three parameters 'the context, id of the layout (it will be where the data is shown),
        // and the array that contains the data
        adapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_checked, arrayList);
        adapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_multiple_choice, arrayList);

        //ListView list = get;
        list.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);

        // Here, you set the data in your ListView
        list.setAdapter(adapter);

        todaysattendance = list.getCheckedItemPositions();

        addbtn = findViewById(R.id.button6);
        addbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                att = todaysattendance.toString();
                writeDb();

            }
        });

    }


    public void writeDb()
    {
        myref= database.getReference().child("Attendance");
        attendance_entry newEntry = new attendance_entry(att,tv.getText().toString());
        myref.push().setValue(newEntry).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                Toast.makeText(Main7Activity.this,"Sucessfully written to db", Toast.LENGTH_SHORT).show();
                finish();
            }
        });

    }

}

