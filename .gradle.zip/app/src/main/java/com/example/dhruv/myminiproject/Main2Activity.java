package com.example.dhruv.myminiproject;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

//Student Login Page
public class Main2Activity extends AppCompatActivity {
    private TextView TV;
    private EditText email;
    private EditText pass;
    FirebaseAuth mAuth;
    private static String name;

    public static String getName() {
        return name;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        TV= (TextView) findViewById(R.id.textView);
        email = (EditText) findViewById(R.id.mail);
        pass = (EditText) findViewById(R.id.pass);
        mAuth = FirebaseAuth.getInstance();

        Button b3=(Button)findViewById(R.id.button3);
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String password = pass.getText().toString();
                String em = email.getText().toString();
                name = em;
                mAuth.signInWithEmailAndPassword(em, password)
                        .addOnCompleteListener(Main2Activity.this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    // Sign in success, update UI with the signed-in user's information
                                    FirebaseUser user = mAuth.getCurrentUser();
                                    Intent i=new Intent(Main2Activity.this,Main4Activity.class);
                                    startActivity(i);

                                } else {
                                    // If sign in fails, display a message to the user.
                                    Toast.makeText(Main2Activity.this, "Please check your username or password!",
                                            Toast.LENGTH_LONG).show();
                                }

                                // ...
                            }
                        });

//                Intent i=new Intent(Main2Activity.this,Main4Activity.class);
//                startActivity(i);
 }

        });
    }

    @Override
    public void onStart() {
        super.onStart();
        // Check if user is signed in (non-null) and update UI accordingly.
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if(currentUser != null) {
            //Intent here
        }

    }
}
